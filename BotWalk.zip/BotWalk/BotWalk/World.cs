﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BotWalk.Utility;
using static System.Console;
namespace BotWalk
{
    class World
    {
        List<Bot> bots = new List<Bot>();

        public World()
        {
            //Set up UI/Interface
            Setup();
            //add bots to list
            SetupBots();
            //greeting
            Greeting();
            //prompt for player action - menu choice?
            while (true)
                Menu();
        }

        private bool BotList()
        {
            if (bots.Count >= 1)
                return true;

            return false;
        }
        private void Menu()
        {
            if(BotList())
            {
                Print("Which Bot would you like to activate?");
                foreach (Bot bot in bots)
                {
                    Print($"   -{bot.Name1} ({bot.Description})");
                }
            }

            string input = ReadLine();
        }
        private void Greeting() 
        {
            Print("Welcome to Bot World Human");
        }
        private void Setup()
        {
            Title = "Bot World";
            BackgroundColor = ConsoleColor.White;
            ForegroundColor = ConsoleColor.DarkBlue;
            Clear();

        }
        private void SetupBots()
        {
            //add bots to list
            bots.Add(new Bot("Bot", "Can tell  the Time"));
            bots.Add(new Trebot("TreBot", "Fancy Trivia Bot"));
            bots.Add(new Sharkbot("SharkBot", "Card Dealer Bot"));
        }

    }
}
