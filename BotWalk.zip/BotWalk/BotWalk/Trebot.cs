﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BotWalk
{
    class Trebot : Bot
    {
        public Trebot(string _name, string _description) : base(_name, _description)
        {

        }
        public override void Act()
        {

        }
    }
}
