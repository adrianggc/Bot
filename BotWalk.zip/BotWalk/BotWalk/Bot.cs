﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static BotWalk.Utility;

namespace BotWalk
{
    class Bot
    {
        private string Name = "Bot";
        public string Name1 { get => Name; }
        public string Description = "";
        private const int ID = 0;

        public Bot(string _name, string _description)
        {
            Name = _name;
            Description = _description;
        }

        public virtual void Act() { }
       
        //example of polymorphism with method overloading 
        public void Talk() { }
        public void Talk(string message) 
        {
            //example os separation of concern
            Print(message);
        }
        
    }
}
